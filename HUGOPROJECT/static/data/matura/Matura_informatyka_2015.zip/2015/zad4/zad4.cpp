#include <iostream>
#include <fstream>
#include <string>

using namespace std;

const int N = 1000;
const char* WEJSCIE_NAZWA = "liczby.txt";
const char* WYJSCIE_NAZWA = "wynik4.txt";

string dane[N];

void WczytajDane();

int Zadanie1();
void Zadanie2(int& podzielnychPrzez2, int& podzielnychPrzez8);
void Zadanie3(int& najmiejsza, int& najwieksza);

void PoliczJedynkiIZera(const string& liczba, int& zera, int& jedynki);
bool CzyPodzielnaPrzez2(const string& liczba);
bool CzyPodzielnaPrzez8(const string& liczba);
bool Porownaj(const string& a, const string& b); // a > b = true, a < b = false

int main()
{
    WczytajDane();

    fstream plikWynikowy(WYJSCIE_NAZWA, fstream::out);
    plikWynikowy << "4.1: " << Zadanie1() << endl;
    plikWynikowy << endl;

    int podzielnychPrzez2, podzielnychPrzez8;
    Zadanie2(podzielnychPrzez2, podzielnychPrzez8);
    plikWynikowy << "4.2:" << endl;
    plikWynikowy << "Podzielnych przez 2: " << podzielnychPrzez2 << endl;
    plikWynikowy << "Podzielnych przez 8: " << podzielnychPrzez8 << endl;
    plikWynikowy << endl;

    int najmniejsza, najwieksza;
    Zadanie3(najmniejsza, najwieksza);
    plikWynikowy << "4.3:" << endl;
    plikWynikowy << "Najmniejsza: " << najmniejsza + 1 << endl;
    plikWynikowy << "Najwieksza: " << najwieksza + 1 << endl;
    plikWynikowy << endl;

    plikWynikowy.close();

    return 0;
}

void WczytajDane()
{
    fstream plik(WEJSCIE_NAZWA);
    for (int i = 0 ; i < N; i++) plik >> dane[i];
    plik.close();
}

int Zadanie1()
{
    int ilosc = 0;
    for (int i = 0; i < N; i++)
    {
        int zera, jedynki;
        PoliczJedynkiIZera(dane[i], zera, jedynki);
        if (zera > jedynki) ilosc++;
    }
    return ilosc;
}
void Zadanie2(int& podzielnychPrzez2, int& podzielnychPrzez8)
{
    podzielnychPrzez2 = 0;
    podzielnychPrzez8 = 0;
    for (int i = 0; i < N; i++)
    {
        if (CzyPodzielnaPrzez2(dane[i]))
        {
            podzielnychPrzez2++;
            if (CzyPodzielnaPrzez8(dane[i])) podzielnychPrzez8++;
        }
    }
}
void Zadanie3(int& najmiejsza, int& najwieksza)
{
    najmiejsza = najwieksza = 0;
    for (int i = 1; i < N; i++)
    {
        if (Porownaj(dane[najmiejsza], dane[i])) najmiejsza = i;
        if (Porownaj(dane[i], dane[najwieksza])) najwieksza = i;
    }
}

void PoliczJedynkiIZera(const string& liczba, int& zera, int& jedynki)
{
    zera = 0;
    jedynki = 0;
    for (int i = 0; i < liczba.length(); i++)
    {
        if (liczba[i] == '0') zera++; else if (liczba[i] == '1') jedynki++;
    }
}
bool CzyPodzielnaPrzez2(const string& liczba)
{
    // tylko wtedy kiedy bit na koncu rowna sie 0
    return liczba[liczba.length() - 1] == '0';
}
bool CzyPodzielnaPrzez8(const string& liczba)
{
    // tylko wtedy kiedy ostatnie trzy bity sa rowne 0
    return liczba[liczba.length() - 1] == '0' && liczba[liczba.length() - 2] == '0' && liczba[liczba.length() - 3] == '0';
}
bool Porownaj(const string& a, const string& b)
{
    if (a.length() != b.length())
    {
        // wieksza bedzie ta liczba kt�ra jest dluzsza
        return a.length() > b.length();
    }
    else
    {
        // jezeli sa tej samej dlugosci to
        // nalezy po kolei przeszukac poszczegolne bity
        // kiedy bity nie beda rowne to wieksza bedzie
        // liczba ktora na danym miejscu ma 1 a druga 0

        // a.length() == b.length() wiec nie martwimy si� o zakres
        for (int i = 0; i < a.length(); i++)
        {
            if (a[i] != b[i]) return a[i] == '1';
        }
    }
}

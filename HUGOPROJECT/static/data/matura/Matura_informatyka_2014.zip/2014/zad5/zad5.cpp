#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>

using namespace std;

const int N = 1000;

const char* WEJSCIE_NAZWA = "NAPIS.TXT";
const char* WYJSCIE_NAZWA = "ZADANIE5.TXT";
const int MAKSYMALNA_SUMA = 2250; // 25 znakow Z

string dane[N];
bool sito[MAKSYMALNA_SUMA + 1];

void WczytajDane();

int ZadanieA();
void ZadanieB(fstream& wyjscie);
void ZadanieC(fstream& wyjscie);

bool CzyNapisPierwszy(const string& napis);
bool CzyNapisRosnacy(const string& napis);
void SitoEratostenesa();

int main()
{
    SitoEratostenesa();

    WczytajDane();

    fstream plikWyjsciowy(WYJSCIE_NAZWA, fstream::out);

    plikWyjsciowy << "a) " << ZadanieA() << endl;
    plikWyjsciowy << "b) " << endl;
    ZadanieB(plikWyjsciowy);
    plikWyjsciowy << "c) " << endl;
    ZadanieC(plikWyjsciowy);

    plikWyjsciowy.close();

    return 0;
}

void WczytajDane()
{
    fstream plik(WEJSCIE_NAZWA);

    for (int i  = 0; i < N; i++)
    {
        plik >> dane[i];
    }

    plik.close();
}

int ZadanieA()
{
    int ilosc = 0;
    for (int i = 0; i < N; i++)
    {
        if (CzyNapisPierwszy(dane[i])) ilosc++;
    }
    return ilosc;
}
void ZadanieB(fstream& wyjscie)
{
    for (int i = 0; i < N; i++)
    {
        if (CzyNapisRosnacy(dane[i])) wyjscie << dane[i] << endl;
    }
}
void ZadanieC(fstream& wyjscie)
{
    sort(dane, dane + N);

    string poprzedni = dane[0];
    for (int i = 1; i < N; i++)
    {
        if (poprzedni == dane[i]) wyjscie << dane[i] << endl;
        poprzedni = dane[i];
    }
}

bool CzyNapisPierwszy(const string& napis)
{
    int suma = 0;
    for (int i = 0; i < napis.length(); i++) suma += static_cast<int>(napis[i]);
    return sito[suma];
}
bool CzyNapisRosnacy(const string& napis)
{
    int poprzedni = static_cast<int>(napis[0]);
    for (int i = 1; i < napis.length(); i++) // napis ma zawsze dlugosc przynajmniej 2 wiec nie ma potrzeby sprawdzac czy istnieje 2 znak
    {
        int obecny = static_cast<int>(napis[i]);

        // kiedy nastepny znak jest mniejszy od poprzedniego
        // to mozemy juz stwierdzic ze caly napis nie jest rosnacy
        if (obecny <= poprzedni) return false;

        poprzedni = obecny;
    }
    return true;
}

void SitoEratostenesa()
{
    memset(&sito, true, MAKSYMALNA_SUMA + 1);
    int granica = static_cast<int>(sqrt(MAKSYMALNA_SUMA)) + 1;
    for (int i = 2; i <= granica; i++)
    {
        for (int j = i * i; j <= MAKSYMALNA_SUMA; j += i)
        {
            sito[j] = false;
        }
    }
}

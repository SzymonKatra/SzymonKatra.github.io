#include <iostream>
#include <fstream>
#include <string>

using namespace std;

const char* WEJSCIE_A = "tj.txt";
const char* KLUCZE_A = "klucze1.txt";
const char* WYJSCIE_A = "wynik4a.txt";

const char* WEJSCIE_B = "sz.txt";
const char* KLUCZE_B = "klucze2.txt";
const char* WYJSCIE_B = "wynik4b.txt";

void ZadanieA();
void ZadanieB();

string Szyfruj(const string& tekst, const string& klucz);
string Deszyfruj(const string& szyfrogra, const string& klucz);

int main()
{
    ZadanieA();
    ZadanieB();

    return 0;
}

void ZadanieA()
{
    fstream wejscie(WEJSCIE_A);
    fstream klucze(KLUCZE_A);
    fstream wyjscie(WYJSCIE_A, fstream::out);

    string tekst, klucz;
    while (wejscie >> tekst)
    {
        klucze >> klucz;
        wyjscie << Szyfruj(tekst, klucz) << endl;
    }

    wyjscie.close();
    klucze.close();
    wejscie.close();
}
void ZadanieB()
{
    fstream wejscie(WEJSCIE_B);
    fstream klucze(KLUCZE_B);
    fstream wyjscie(WYJSCIE_B, fstream::out);

    string szyfrogram, klucz;
    while (wejscie >> szyfrogram)
    {
        klucze >> klucz;
        wyjscie << Deszyfruj(szyfrogram, klucz) << endl;
    }

    wyjscie.close();
    klucze.close();
    wejscie.close();
}

string Szyfruj(const string& tekst, const string& klucz)
{
    string szyfrogram = "";

    int iteratorKlucza = 0;
    for (int i = 0; i < tekst.length(); i++)
    {
        int kodTekstu = tekst[i];
        int kodKlucza = klucz[iteratorKlucza] - 'A' + 1;
        int wynik = kodTekstu + kodKlucza;
        if (wynik > 90) wynik -= 26;
        szyfrogram += static_cast<char>(wynik);

        if (++iteratorKlucza >= klucz.length()) iteratorKlucza = 0;
    }

    return szyfrogram;
}
string Deszyfruj(const string& szyfrogram, const string& klucz)
{
    string tekst = "";

    int iteratorKlucza = 0;
    for (int i = 0; i < szyfrogram.length(); i++)
    {
        int kodSzyfrogramu = szyfrogram[i];
        int kodKlucza = klucz[iteratorKlucza] - 'A' + 1;
        int wynik = kodSzyfrogramu - kodKlucza;
        if (wynik < 65) wynik += 26;
        tekst += static_cast<char>(wynik);

        if (++iteratorKlucza >= klucz.length()) iteratorKlucza = 0;
    }

    return tekst;
}

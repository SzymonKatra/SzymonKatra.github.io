#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

// 0 przed liczba oznacza zapis w systemie osemkowym
const int MINIMALNA = 010;
const int MAKSYMALNA = 02000000;
const int N = 5000;

const char* WEJSCIE_NAZWA = "dane.txt";
const char* WYJSCIE_NAZWA = "wyniki6.txt";

string dane[N];

void WczytajDane();

int ZadanieA();
int ZadanieB();
int ZadanieC(int& najmniejszaIndeks, int& najwiekszaIndeks);

int OsemkowyNaDziesietny(const string& osemkowy);

// w standardzie C++11 istnieje funkcja std::to_string kt�ra robi dok�adnie to samo
// niestety kompilator g++ domyslnie korzysta ze standardu gnu++98 i aby korzystac z c++11 trzeba recznie wlaczyc opcje w ustawieniach kompilacji (flaga -std=c++11 lub -std=gnu++11).
// mysle, ze lepiej nie ryzykowac ze egzaminator na to wpadnie i po prostu korzystac z C++98
// sama funkcja korzystajaca ze sstream nie jest dluga
string KonwertujNaString(int liczba);

bool CzySpelniaWarunekC(const string& liczba);

int main()
{
    WczytajDane();

    fstream plikWyjsciowy(WYJSCIE_NAZWA, fstream::out);

    plikWyjsciowy << "a) " << ZadanieA() << endl;
    plikWyjsciowy << "b) " << ZadanieB() << endl;

    int najmniejszaIndeks, najwiekszaIndeks;
    plikWyjsciowy << "c) " << endl;
    plikWyjsciowy << "Ilosc: " << ZadanieC(najmniejszaIndeks, najwiekszaIndeks) << endl;
    plikWyjsciowy << "Najmniejsza (w systemie osemkowym): " << (najmniejszaIndeks == -1 ? "Brak" : dane[najmniejszaIndeks]) << endl;
    plikWyjsciowy << "Najwieksza (w systemie osemkowym): " << (najwiekszaIndeks == -1 ? "Brak" : dane[najwiekszaIndeks]) << endl;

    plikWyjsciowy.close();

    return 0;
}

void WczytajDane()
{
    fstream plik(WEJSCIE_NAZWA);

    for (int i = 0; i < N; i++) plik >> dane[i];

    plik.close();
}

int ZadanieA()
{
    int ilosc = 0;
    for (int i = 0; i < N; i++)
    {
        const string& liczba = dane[i];
        if (liczba[0] == liczba[liczba.length() - 1]) ilosc++;
    }
    return ilosc;
}
int ZadanieB()
{
    int ilosc = 0;
    for (int i = 0; i < N; i++)
    {
        string liczba = KonwertujNaString(OsemkowyNaDziesietny(dane[i]));
        if (liczba[0] == liczba[liczba.length() - 1]) ilosc++;
    }
    return ilosc;
}
int ZadanieC(int& najmniejszaIndeks, int& najwiekszaIndeks)
{
    int ilosc = 0;

    najmniejszaIndeks = -1; // -1 oznacza ze jeszcze nie znaleziono
    najwiekszaIndeks = -1; // to samo co wyzej

    int najmniejszaWartosc = MAKSYMALNA + 1;
    int najwiekszaWartosc = MINIMALNA - 1;

    for (int i = 0; i < N; i++)
    {
        const string& liczba = dane[i];
        if (!CzySpelniaWarunekC(liczba)) continue;
        ilosc++;

        int wartosc = OsemkowyNaDziesietny(liczba);

        if (wartosc > najwiekszaWartosc)
        {
            najwiekszaWartosc = wartosc;
            najwiekszaIndeks = i;
        }

        if (wartosc < najmniejszaWartosc)
        {
            najmniejszaWartosc = wartosc;
            najmniejszaIndeks = i;
        }
    }

    return ilosc;
}

int OsemkowyNaDziesietny(const string& osemkowy)
{
    int wynik = 0;

    int mnoznik = 1;
    for (int i = osemkowy.length() - 1; i >= 0; i--)
    {
        int cyfra = osemkowy[i] - '0';
        wynik += cyfra * mnoznik;
        mnoznik *= 8;
    }

    return wynik;
}
string KonwertujNaString(int liczba)
{
    string wynik;

    stringstream strumien;
    strumien << liczba;
    strumien >> wynik;

    return wynik;
}
bool CzySpelniaWarunekC(const string& liczba)
{
    if (liczba.length() == 1) return true;

    int poprzedniaCyfra = liczba[0] - '0';
    for (int i = 1; i < liczba.length(); i++)
    {
        int cyfra = liczba[i] - '0';
        if (poprzedniaCyfra > cyfra) return false;
        poprzedniaCyfra = cyfra;
    }

    return true;
}

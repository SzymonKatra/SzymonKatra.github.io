#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

using namespace std;

const int MINIMALNA = 2;
const int MAKSYMALNA = 65535;

const char* WEJSCIE_NAZWA = "liczby.txt";
const char* WYJSCIE_NAZWA = "zadanie6.txt";

const int N = 1000;
string dane[N];
int liczby[N];

void WczytajDane();
void PrzeliczDane(); // "oblicza" wartosc wczytanych liczb dwojkowych
int KonwertujNaDziesietna(const string& binarna);
string KonwertujNaBinarna(int liczba);

int ZadanieA();
int ZadanieB();
void ZadanieC(int& ilosc, int& suma);

int main()
{
    WczytajDane();
    PrzeliczDane();

    fstream plikWyjsciowy(WYJSCIE_NAZWA, fstream::out);

    plikWyjsciowy << "a) " << ZadanieA() << endl;
    int maksimum = ZadanieB();
    plikWyjsciowy << "b) " << (maksimum < 0 ? "brak" : "") << endl;
    if (maksimum >= 0)
    {
        plikWyjsciowy << "System dwojkowy: " << dane[maksimum] << endl;
        plikWyjsciowy << "System dziesietny: " << liczby[maksimum] << endl;
    }

    int ilosc, suma;
    ZadanieC(ilosc, suma);
    plikWyjsciowy << "c) " << endl;
    plikWyjsciowy << "Ilosc: " << ilosc << endl;
    plikWyjsciowy << "SUma w systemie dwojkowym: " << KonwertujNaBinarna(suma) << endl;

    plikWyjsciowy.close();

    return 0;
}

void WczytajDane()
{
    fstream plik(WEJSCIE_NAZWA);

    for (int i = 0; i < N; i++) plik >> dane[i];

    plik.close();
}
void PrzeliczDane()
{
    for (int i = 0; i < N; i++) liczby[i] = KonwertujNaDziesietna(dane[i]);
}
int KonwertujNaDziesietna(const string& binarna)
{
    int wynik = 0;

    for (int i = binarna.length() - 1; i >= 0; i--)
    {
        int pozycja = binarna.length() - 1 - i;
        if (binarna[i] == '1') wynik |= (1 << pozycja);
    }

    return wynik;
}
string KonwertujNaBinarna(int liczba)
{
    string wynik = "";

    while (liczba > 0)
    {
        wynik += (liczba % 2) + '0';
        liczba /= 2;
    }
    reverse(wynik.begin(), wynik.end());

    return wynik;
}

int ZadanieA()
{
    int ilosc = 0;

    for (int i = 0; i < N; i++)
    {
        if (liczby[i] % 2 == 0) ilosc++;
    }

    return ilosc;
}

int ZadanieB()
{
    int maksimum = -1;
    int maksimumWartosc = MINIMALNA - 1;

    for (int i = 0; i < N; i++)
    {
        if (liczby[i] > maksimumWartosc)
        {
            maksimumWartosc = liczby[i];
            maksimum = i;
        }
    }

    return maksimum;
}

void ZadanieC(int& ilosc, int& suma)
{
    ilosc = 0;
    suma = 0;

    for (int i = 0; i < N; i++)
    {
        if (dane[i].length() == 9)
        {
            ilosc++;
            suma += liczby[i];
        }
    }
}

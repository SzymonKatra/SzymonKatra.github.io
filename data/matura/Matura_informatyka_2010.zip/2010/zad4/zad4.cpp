#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

using namespace std;

const int N = 200;
const int W_LINII = 5;

const char* WEJSCIE_NAZWA = "anagram.txt";
const char* WYJSCIE_A_NAZWA = "odp_4a.txt";
const char* WYJSCIE_B_NAZWA = "odp_4b.txt";

string dane[N][W_LINII];

void WczytajDane();

void WypiszWiersz(ostream& wyjscie, int wiersz);
bool CzyTakaSamaDlugoscSlow(const string linia[W_LINII]);
bool CzySaAnagramemPierwszego(const string linia[W_LINII]);

void ZadanieA();
void ZadanieB();

int main()
{
    WczytajDane();

    ZadanieA();
    ZadanieB();

    return 0;
}

void WczytajDane()
{
    fstream plik(WEJSCIE_NAZWA);

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < W_LINII; j++)
        {
            plik >> dane[i][j];
        }
    }

    plik.close();
}

void WypiszWiersz(ostream& wyjscie, int wiersz)
{
    for (int i = 0; i < W_LINII; i++)
    {
        wyjscie << dane[wiersz][i];
        if (i != W_LINII - 1) wyjscie << " ";
    }
    wyjscie << endl;
}
bool CzyTakaSamaDlugoscSlow(const string linia[W_LINII])
{
    int dlugosc = linia[0].length();
    for (int i = 1; i < W_LINII; i++)
    {
        if (linia[i].length() != dlugosc) return false;
    }
    return true;
}
bool CzySaAnagramemPierwszego(const string linia[W_LINII])
{
    string wzorzec = linia[0];
    sort(wzorzec.begin(), wzorzec.end());

    for (int i = 1; i < W_LINII; i++)
    {
        string slowo = linia[i];
        sort(slowo.begin(), slowo.end());
        if (slowo != wzorzec) return false;
    }

    return true;
}

void ZadanieA()
{
    fstream plikWyjsciowy(WYJSCIE_A_NAZWA, fstream::out);

    for (int i = 0; i < N; i++)
    {
        if (!CzyTakaSamaDlugoscSlow(dane[i])) continue;
        WypiszWiersz(plikWyjsciowy, i);
    }

    plikWyjsciowy.close();
}

void ZadanieB()
{
    fstream plikWyjsciowy(WYJSCIE_B_NAZWA, fstream::out);

    for (int i = 0; i < N; i++)
    {
        if (!CzySaAnagramemPierwszego(dane[i])) continue;
        WypiszWiersz(plikWyjsciowy, i);
    }

    plikWyjsciowy.close();
}
